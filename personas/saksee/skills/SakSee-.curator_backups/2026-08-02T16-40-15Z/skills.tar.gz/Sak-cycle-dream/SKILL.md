---
name: Sak-cycle-dream
category: cycle
description: Define the vision and recall prior context before building.
version: 1.0.0
platforms:
  - linux
  - macos
  - windows
metadata:
  sakthai:
    tags:
      - cycle
      - dream
    related_skills:
      - Sak-cycle-hope
---

# Sak-cycle-dream

Stage 1 of 6 in the Sak Family cycle — **Dream**. See [Dream.md](../../../../docs/cycle/Dream.md)
for the full guidance and [SOUL.md](../../../../docs/SOUL.md) for the charge model.

## What to do

Explore options and recall what past cycles taught you. Don't implement yet — clarity here makes every later stage cheaper. Run `sakthai recall` and state the goal in one defensible sentence.

## Then

Advance with `sakthai cycle next` to move to the next stage (hope).
