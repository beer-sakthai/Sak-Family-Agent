---
name: SakSee-sakthai-cycle-care
version: 1.0.0
description: "Saksee Sakthai Cycle Care"
category: sakthai-cycle-care

---
# SakThai Cycle — Care

Audit correctness, safety, and performance before shipping.
1. **Security scan** — secrets, dependencies, injection risks
2. **Error handling** — what breaks, how does it fail
3. **Performance** — slow paths, N+1 queries
4. **Save findings** — to memory for next stage
