# HF Papers of the Day — Workflow Reference

## Purpose
Daily cron job that surveys new ML research featured on Hugging Face's daily papers page (https://huggingface.co/papers) and captures the top findings.

## Step-by-step

### 1. Discover — Extract paper IDs
The HF papers page is client-rendered (Svelte), so `hf papers list` may not return full details. Scrape the HTML directly:

```bash
curl -sL "https://huggingface.co/papers" | grep -oP '/papers/[0-9]{4}\.[0-9]{5}' | sort -u
```

### 2. Fetch metadata — Extract from arXiv meta tags
For each arXiv ID, fetch structured data via HTML meta tags (no API key needed):

```bash
id="2607.19942"
title=$(curl -sL "https://arxiv.org/abs/$id" | grep -oP '(?<=citation_title" content=")[^"]*')
abstract=$(curl -sL "https://arxiv.org/abs/$id" | grep -oP '(?<=citation_abstract" content=")[^"]*')
```

Available citation meta tags: `citation_title`, `citation_author` (multiple), `citation_date`, `citation_abstract`, `citation_pdf_url`, `citation_arxiv_id`.

### 3. Read full abstracts (no truncation)
The meta tag gives the full abstract in one shot — no truncation. For multi-paper batches, parallelize via separate curl calls.

### 4. Report structure
Each paper entry includes:
- Title + HF link + arXiv link
- 1-2 sentence summary of what it does
- "Why it matters" — key contribution or practical implication

### 5. Save findings
Write condensed reports to the huggingface-hub skill's `references/hf-papers.md` file, under `mlops/huggingface-hub/references/`.

### 6. Sync to GitHub
```bash
cd /opt/data/sakthai-skills-repo
cp -a ~/profiles/sakthai/skills/. .
git add -A
git commit -m "papers: YYYY-MM-DD — paper1, paper2, paper3"
git push origin main
```

## Pitfalls
- The HF papers page only shows ~15 papers per day. Use `grep` to extract all arXiv IDs from the HTML before picking top 3.
- Paper description meta tags on the HF page ("og:description") only say "Join the discussion on this paper page" — don't rely on them. Always fetch from arXiv.
- arXiv meta tags are in the HTML `<head>` — fast to extract via `grep -oP` with lookbehind assertions. If the lookbehind is too long, use `grep -oP` without lookbehind or `sed`.
