---
name: hf-diffusion-course
description: "Generate images with Diffusers and diffusion models."
version: 0.1.0
author: Hermes
tags: [Diffusion, ImageGeneration, Diffusers, StableDiffusion, HuggingFace]
---

# Diffusion Models with Diffusers

Based on the [HF Diffusion Course](https://huggingface.co/learn/diffusion-course). Covers theory and practice of diffusion models — DDPM, fine-tuning, Stable Diffusion, DDIM inversion, and diffusion for audio.

## When to Use

- User wants to "generate images with AI"
- User asks about Stable Diffusion, Diffusers, or LoRA for image models
- User wants to fine-tune a diffusion model on custom data
- User needs to create custom diffusion pipelines

## Prerequisites

- `pip install diffusers transformers accelerate torch`
- For Stable Diffusion: a GPU with ≥8GB VRAM (or use HF Inference API)
- HF token for gated models: `huggingface-cli login`

## Quick Reference

| Concept | Library | Description |
|---------|---------|-------------|
| Pipeline | `diffusers` | Ready-to-use generation (`StableDiffusionPipeline`) |
| Scheduler | `diffusers` | Noise scheduler (DDIM, PNDM, LMSDiscrete, DPM++) |
| UNet | `diffusers` | Core denoising architecture |
| VAE | `diffusers` | Encode/decode to latent space |
| LoRA | `peft` | Lightweight fine-tuning adapters |

## Procedure

### Text-to-Image
```python
from diffusers import StableDiffusionPipeline
pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
pipe.to("cuda")
image = pipe("A cat wearing a space helmet").images[0]
image.save("cat-space.png")
```

### Fine-tune with LoRA
```python
from diffusers import DiffusionPipeline
import torch
pipe = DiffusionPipeline.from_pretrained("stable-diffusion-v1-5/stable-diffusion-v1-5")
# Train LoRA weights on custom images
pipe.unet.load_attn_procs(...)
# Save adapter
pipe.save_pretrained("./my-lora")
```

### DDIM Inversion
Reverse the diffusion process to edit real images:
```python
from diffusers import DDIMInverseScheduler, DDIMScheduler
inverse_scheduler = DDIMInverseScheduler.from_config(pipe.scheduler.config)
```

## Pitfalls

- Different schedulers produce different quality/speed tradeoffs. Try DPM++ for quality.
- LoRA training needs carefully captioned images — bad captions = bad results.
- Stable Diffusion models may have license restrictions — check the model card.
- DDIM inversion is lossy; expect minor quality degradation on reconstruction.

## Verification

```python
from diffusers import DiffusionPipeline
pipe = DiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5")
img = pipe("test").images[0]
print(f"Generated {img.size}")
```
