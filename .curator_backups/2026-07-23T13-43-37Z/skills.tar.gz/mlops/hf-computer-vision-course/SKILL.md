---
name: hf-computer-vision-course
description: "Computer vision with HF — classification, detection, more."
version: 0.1.0
author: Hermes
tags: [ComputerVision, ImageClassification, ObjectDetection, HuggingFace, ViT]
---

# Computer Vision with Hugging Face

Based on the [Community HF Computer Vision Course](https://huggingface.co/learn/computer-vision-course). Covers CNNs, Vision Transformers (ViT), multimodal models, generative CV, object detection, segmentation, video processing, 3D vision, optimization, and synthetic data.

## When to Use

- User wants to "classify images" or "detect objects"
- User asks about Vision Transformers (ViT) or image segmentation
- User needs to train/fine-tune a CV model
- User wants zero-shot classification or synthetic data generation

## Prerequisites

- `pip install transformers datasets torch torchvision`
- For detection: `pip install timm`
- GPU recommended for training

## Quick Reference

| Task | Model | Pipeline |
|------|-------|----------|
| Image Classification | `google/vit-base-patch16-224` | `pipeline("image-classification")` |
| Object Detection | `facebook/detr-resnet-50` | `pipeline("object-detection")` |
| Image Segmentation | `facebook/detr-resnet-50-panoptic` | `pipeline("image-segmentation")` |
| Depth Estimation | `Intel/dpt-hybrid-midas` | `pipeline("depth-estimation")` |
| Zero-shot Classification | `openai/clip-vit-base-patch32` | `pipeline("zero-shot-image-classification")` |

## Procedure

### Image Classification
```python
from transformers import pipeline
pipe = pipeline("image-classification", model="google/vit-base-patch16-224")
result = pipe("https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/cat.png")
print(result)
```

### Object Detection
```python
pipe = pipeline("object-detection", model="facebook/detr-resnet-50")
results = pipe("image.jpg")
for r in results: print(r["label"], r["score"], r["box"])
```

### Fine-tune a ViT
```python
from transformers import ViTForImageClassification, ViTImageProcessor
model = ViTForImageClassification.from_pretrained("google/vit-base-patch16-224", num_labels=10)
processor = ViTImageProcessor.from_pretrained("google/vit-base-patch16-224")
# Train with Trainer API or custom training loop
```

## Pitfalls

- Detection/segmentation models expect specific input sizes — use the model's processor.
- ViT models need normalized inputs — use the processor, not raw images.
- Zero-shot CLIP works best with natural images; performance drops on medical/domain-specific images.
- Video processing is memory-intensive — process frame-by-frame or use temporal pooling.

## Verification

```python
from transformers import pipeline
pipe = pipeline("image-classification")
print(pipe("https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/cat.png"))
```
