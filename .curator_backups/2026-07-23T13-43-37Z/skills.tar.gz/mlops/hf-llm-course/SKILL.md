---
name: hf-llm-course
description: "Reference for Hugging Face Transformers and LLM workflows."
version: 0.1.0
author: Hermes
tags: [LLM, NLP, Transformers, HuggingFace, Course]
---

# LLM Course — Transformers & NLP Reference

Based on the [HF LLM Course](https://huggingface.co/learn/llm-course). Covers using Transformers, Datasets, Tokenizers, and Accelerate for NLP and LLM tasks.

## When to Use

- User needs to load or use a transformer model for NLP
- User asks about tokenizers, datasets, or model sharing on the Hub
- User wants to fine-tune or evaluate a pretrained model
- User needs to build a Gradio demo for a model

## Prerequisites

- `transformers`, `datasets`, `tokenizers`, `accelerate`, `gradio` — install via pip
- HF account for model sharing at [huggingface.co/join](https://huggingface.co/join)

## Quick Reference

| Library | Install | Key Use |
|---------|---------|---------|
| Transformers | `pip install transformers` | Load/infer/fine-tune any HF model |
| Datasets | `pip install datasets` | Load, process, stream datasets |
| Tokenizers | `pip install tokenizers` | Fast tokenization (Rust backend) |
| Accelerate | `pip install accelerate` | Multi-GPU/mixed-precision training |
| Gradio | `pip install gradio` | Build interactive demos |

## Procedure

1. **Load a model and tokenizer:**
   ```python
   from transformers import AutoModelForCausalLM, AutoTokenizer
   model = AutoModelForCausalLM.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
   tokenizer = AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
   ```

2. **Run inference:**
   ```python
   inputs = tokenizer("Hello, I am", return_tensors="pt")
   outputs = model.generate(**inputs, max_new_tokens=50)
   print(tokenizer.decode(outputs[0]))
   ```

3. **Load a dataset:**
   ```python
   from datasets import load_dataset
   dataset = load_dataset("imdb", split="train")
   ```

4. **Fine-tune with Trainer:**
   ```python
   from transformers import Trainer, TrainingArguments
   training_args = TrainingArguments(output_dir="./results", num_train_epochs=3)
   trainer = Trainer(model=model, args=training_args, train_dataset=dataset)
   trainer.train()
   ```

5. **Share to Hub:**
   ```python
   model.push_to_hub("your-username/model-name")
   tokenizer.push_to_hub("your-username/model-name")
   ```

6. **Build a Gradio demo:**
   ```python
   import gradio as gr
   gr.Interface(fn=predict, inputs="text", outputs="text").launch()
   ```

## Pitfalls

- Tokenizer must match the model — using mismatched tokenizers produces garbage output.
- For large models, use `device_map="auto"` and `torch_dtype=torch.float16` to fit in GPU memory.
- `datasets` streaming mode (`streaming=True`) avoids downloading full datasets.

## Verification

```python
from transformers import pipeline; pipe = pipeline("text-classification"); print(pipe("HF is great!"))
```
