---
name: hf-learn-portal
description: "Navigate and recommend Hugging Face Learn courses."
version: 0.1.0
author: Hermes
tags: [HuggingFace, Courses, Learning, Education, LLM, Agents, NLP]
---

# Hugging Face Learn Portal Guide

A catalog of all free courses on the [Hugging Face Learn](https://huggingface.co/learn) portal. Each course uses libraries from the HF ecosystem and is free, self-paced, and open-source. Use this skill to recommend a learning path, find the right course for a task, or explore what's available.

Does NOT cover tutorials or blog posts outside the official HF Learn portal.

## When to Use

- User asks "what HF courses are available?"
- User wants to "learn Hugging Face" or "start learning NLP/LLMs"
- User wants to "learn agents" or "learn fine-tuning"
- User asks for "free AI courses" or "HF learning resources"
- User wants to "learn about AI safety" (no dedicated course — direct to LLM Course)
- User asks "where should I start with Hugging Face?"

## Prerequisites

- A [Hugging Face account](https://huggingface.co/join) (free) — needed for certification, demos, and GPU-spaces
- No paid tier required for any course

## Quick Reference

| Course | URL | Focus |
|--------|-----|-------|
| LLM Course | `/learn/llm-course` | NLP + LLMs with Transformers, Datasets, Tokenizers |
| Agents Course | `/learn/agents-course` | AI Agents (smolagents, LlamaIndex, LangGraph) |
| a smol course | `/learn/smol-course` | Fine-tuning LLMs (instruction tuning, RLHF, eval) |
| Context Course | `/learn/context-course` | Context engineering for code agents |
| Diffusion Course | `/learn/diffusion-course` | Diffusion models with Diffusers |
| Audio Course | `/learn/audio-course` | Transformers for audio (Whisper, speaker diarization) |
| Deep RL Course | `/learn/deep-rl-course` | Deep reinforcement learning |
| Robotics Course | `/learn/robotics-course` | Robot building with LeRobot |
| Computer Vision Course | `/learn/computer-vision-course` | Vision ML (image classification, detection, segmentation) |
| ML for Games Course | `/learn/ml-games-course` | AI in game development |
| ML for 3D Course | `/learn/ml-for-3d-course` | 3D ML (point clouds, NeRF, 3D vision) |
| Open-Source AI Cookbook | `/learn/cookbook` | Practical notebooks by the community |

## Course Details

### LLM Course (NLP → LLMs)
The flagship HF course covering Transformers, Datasets, Tokenizers, and Accelerate libraries. 12 chapters from setup to building demos. Teaches both classic NLP (sentiment analysis, NER, translation) and modern LLM techniques (fine-tuning, reasoning models). Includes certification exam.

URL: `https://huggingface.co/learn/llm-course`  
Key libs: `transformers`, `datasets`, `tokenizers`, `accelerate`, `gradio`

### Agents Course
Teaches AI agents from theory to deployment. Covers the smolagents framework, LlamaIndex, and LangGraph. Includes a final project with certification. Bonus units on fine-tuning LLMs for function-calling, agent observability, and agents in games.

URL: `https://huggingface.co/learn/agents-course`  
Key libs: `smolagents`, `llama-index`, `langgraph`, `gradio`

### a smol course (Fine-Tuning)
The shortest path to fine-tuning LLMs. 5 units: instruction tuning, preference alignment (DPO/RLHF), vision-language models, and evaluation. Designed for software developers who already know code.

URL: `https://huggingface.co/learn/smol-course`  
Key libs: `transformers`, `trl`, `peft`, `datasets`

### Context Course
Focused specifically on context engineering for code agents — structuring prompts, context windows, and tool definitions for agentic code workflows.

URL: `https://huggingface.co/learn/context-course`

### Diffusion Course
Covers theory and practice of diffusion models. Units on DDPM, fine-tuning + guidance, Stable Diffusion, DDIM inversion, and diffusion for audio. Uses the Diffusers library. Includes a DreamBooth hackathon.

URL: `https://huggingface.co/learn/diffusion-course`  
Key libs: `diffusers`, `transformers`, `accelerate`

### Audio Course
Apply transformers to audio data. Covers speech recognition (Whisper), audio classification, speaker diarization, and text-to-speech.

URL: `https://huggingface.co/learn/audio-course`  
Key libs: `transformers`, `datasets`, `gradio`

### Deep RL Course
Deep reinforcement learning using HF ecosystem. Covers DQN, PPO, A2C, and multi-agent RL. Interactive with gymnasium environments.

URL: `https://huggingface.co/learn/deep-rl-course`

### Robotics Course
Build robots using LeRobot. Covers imitation learning, reinforcement learning for robotics, and sim-to-real transfer.

URL: `https://huggingface.co/learn/robotics-course`  
Key libs: `lerobot`

### Community Computer Vision Course
Computer vision ML: image classification, object detection, image segmentation, video understanding. Community-maintained.

URL: `https://huggingface.co/learn/computer-vision-course`  
Key libs: `transformers`, `datasets`, `torchvision`

### ML for Games Course
Integrate AI into games: NPC behavior, procedural content generation, game analytics with ML.

URL: `https://huggingface.co/learn/ml-games-course`

### ML for 3D Course
3D machine learning: point clouds, NeRF, 3D Gaussian splatting, mesh processing.

URL: `https://huggingface.co/learn/ml-for-3d-course`

### Open-Source AI Cookbook
Not a course — a collection of community-contributed notebooks ("recipes") covering MLOps, LLM, vision, diffusion, multimodal, search, agents, and Enterprise Hub patterns. Each notebook solves a practical problem.

URL: `https://huggingface.co/learn/cookbook`  
Repo: `https://github.com/huggingface/cookbook`

## Procedure

1. **Determine the user's goal** — classify the request into one of:
   - "I'm new" → LLM Course (Chapters 1–4)
   - "Fine-tune models" → a smol course
   - "Build agents" → Agents Course
   - "Generate images" → Diffusion Course
   - "Audio/Speech" → Audio Course
   - "Computer Vision" → Computer Vision Course
   - "Robotics" → Robotics Course
   - "Games" → ML for Games Course
   - "3D" → ML for 3D Course
   - "Reinforcement Learning" → Deep RL Course
   - "Context engineering / code agents" → Context Course
   - "Practical recipes / cookbook" → Open-Source AI Cookbook

2. **Recommend the course URL** — navigate to `https://huggingface.co/learn/<course-slug>` via `browser_navigate` or open the URL for the user.

3. **For detailed exploration:** use `terminal` with `curl -sL https://huggingface.co/learn/<course-slug> | ...` to extract the syllabus from the page's `<main>` section.

## Pitfalls

- The Open-Source AI Cookbook is NOT a course — it's a notebook collection. Direct users to it only when they have a specific practical problem.
- All courses are free but some require an HF account for certification, GPU-space demos, or downloading gated model weights.
- Course content is versioned per-language. Some courses have limited localization (check the language selector at the top of the course page).
- The agents curriculum mentions "smolagents" — this is the `smolagents` Python package, distinct from the `smol-course` (fine-tuning).

## Verification

Fetch the course index page to confirm availability:
```bash
curl -sL https://huggingface.co/learn | grep -oP 'href="/learn/[^"]+"' | sed 's/href="//' | sed 's/"//'
```
This should return all 12 course slugs.
