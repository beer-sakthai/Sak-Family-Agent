---
name: hf-smol-course
description: "Fine-tune LLMs with TRL, PEFT, and alignment methods."
version: 0.1.0
author: Hermes
tags: [FineTuning, LLM, TRL, PEFT, RLHF, HuggingFace]
---

# Fine-Tuning LLMs — a smol course

Reference for the [HF smol course](https://huggingface.co/learn/smol-course). Covers instruction tuning, preference alignment (DPO, GRPO), vision-language models, and model evaluation.

## When to Use

- User wants to "fine-tune an LLM"
- User asks about SFT, DPO, GRPO, or RLHF
- User wants to align a model with human preferences
- User needs to evaluate a fine-tuned model

## Prerequisites

- `pip install transformers trl peft accelerate datasets`
- GPU recommended (free: Kaggle, Colab, HF ZeroGPU Spaces)
- Base model from HF Hub

## Procedure

### 1. Instruction Tuning (SFT)
```python
from trl import SFTTrainer
from transformers import AutoModelForCausalLM, AutoTokenizer

model = AutoModelForCausalLM.from_pretrained("model-name")
tokenizer = AutoTokenizer.from_pretrained("model-name")

trainer = SFTTrainer(
    model=model,
    tokenizer=tokenizer,
    train_dataset=dataset,
    args=TrainingArguments(output_dir="./sft-output"),
)
trainer.train()
```

### 2. Preference Alignment (DPO)
```python
from trl import DPOTrainer

dpo_trainer = DPOTrainer(
    model=model,
    ref_model=ref_model,
    tokenizer=tokenizer,
    train_dataset=preference_dataset,
    args=TrainingArguments(output_dir="./dpo-output"),
)
dpo_trainer.train()
```

### 3. GRPO (Group Relative Policy Optimization)
Available in TRL for reasoning-based training. Use with vLLM for efficient rollout generation.

```python
from trl import GRPOTrainer
# Configure reward functions and training args
trainer = GRPOTrainer(model=model, reward_funcs=[...], args=...)
trainer.train()
```

## Pitfalls

- SFT first, THEN alignment (DPO/GRPO). Never skip SFT.
- Preference data requires chosen/rejected pairs — format matters.
- GRPO with vLLM needs GPU memory for both the model and rollout generation.
- Always evaluate on a held-out eval set; loss can drop while quality degrades.

## Verification

Run inference on a held-out prompt and compare before/after:
```python
pipe = pipeline("text-generation", model=trained_model)
print(pipe("Explain transformers simply:")[0]["generated_text"])
```
