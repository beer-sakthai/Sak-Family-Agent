---
name: hf-cookbook
description: "Practical AI notebooks from the Open-Source AI Cookbook."
version: 0.1.0
author: Hermes
tags: [Cookbook, Notebooks, Recipes, HuggingFace, Community]
---

# Open-Source AI Cookbook

Based on the [HF Open-Source AI Cookbook](https://huggingface.co/learn/cookbook). A collection of community-contributed notebooks ("recipes") for practical ML tasks — fine-tuning, inference, deployment, agents, and more. All notebooks are free and open-source.

## When to Use

- User asks for "practical examples" or "real ML recipes"
- User wants to see how to use a specific HF library in practice
- User needs working code for fine-tuning, evaluation, or deployment
- User wants to contribute a recipe to the community

## Prerequisites

- A HF account for running in Spaces or downloading models
- Python environment with relevant libraries
- No paid tier required

## Categories

| Category | Examples |
|----------|----------|
| MLOps | Training pipelines, evaluation, experiment tracking |
| LLM | Fine-tuning, RAG, function-calling, prompting |
| Computer Vision | Image classification, detection, segmentation |
| Diffusion | Text-to-image, LoRA, inpainting, ControlNet |
| Multimodal | Vision-language, audio-visual, CLIP |
| Search | Semantic search, embeddings, retrieval |
| Agents | smolagents, tool use, multi-agent |
| Enterprise Hub | SSO, RBAC, audit logs, storage |

## Procedure

1. **Browse recipes:** go to `https://huggingface.co/learn/cookbook` and scan categories
2. **Find a recipe:** filter by category or search for keywords
3. **Run locally:** download the `.ipynb` notebook and run
4. **Run in Spaces:** fork the associated Space if available
5. **Contribute:** submit PRs to the [GitHub repo](https://github.com/huggingface/cookbook)

### Notable recipes (at time of writing)
- Concurrent Multi-Config SFT Training with RapidFire AI
- Fine-tuning LLMs for Function Calling with the xLAM Dataset
- Optimizing Language Models with DSPy
- Post-training VLM for Reasoning with GRPO using TRL
- Efficient Online Training with GRPO and vLLM in TRL

## Pitfalls

- The cookbook is NOT a structured course — it's a collection of standalone notebooks.
- Notebooks may use specific library versions — check requirements.txt before running.
- Some recipes need GPU — look for ZeroGPU-compatible notebooks.
- Community-contributed means varying quality — check comments and freshness.

## Verification

```bash
curl -sL https://huggingface.co/learn/cookbook | grep -oP 'recipe-\w+' | head -5
```
Returns the first few recipe IDs from the cookbook page.
