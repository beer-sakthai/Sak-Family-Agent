---
name: hf-audio-course
description: "Process audio with transformers — ASR, TTS, classification."
version: 0.1.0
author: Hermes
tags: [Audio, ASR, TTS, Whisper, HuggingFace, Speech]
---

# Audio Transformers with Hugging Face

Based on the [HF Audio Course](https://huggingface.co/learn/audio-course). Covers working with audio data, transformer architectures for audio, ASR (Whisper), TTS, and music genre classification.

## When to Use

- User wants to "transcribe audio" or "convert speech to text"
- User wants to "generate speech from text" (TTS)
- User needs audio classification or music genre detection
- User asks about Whisper, speaker diarization, or audio transformers

## Prerequisites

- `pip install transformers datasets librosa soundfile torch`
- For Whisper: GPU recommended for large models
- Audio files in common formats (wav, mp3, flac)

## Quick Reference

| Task | Model | Pipeline |
|------|-------|----------|
| ASR | `openai/whisper-large-v3` | `pipeline("automatic-speech-recognition")` |
| TTS | `suno/bark` | `pipeline("text-to-speech")` |
| Audio Classification | `facebook/wav2vec2-base` | `pipeline("audio-classification")` |

## Procedure

### Speech Recognition (Whisper)
```python
from transformers import pipeline
pipe = pipeline("automatic-speech-recognition", model="openai/whisper-large-v3")
result = pipe("speech.mp3")
print(result["text"])
```

### Text-to-Speech
```python
pipe = pipeline("text-to-speech", model="suno/bark")
output = pipe("Hello, welcome to the Hugging Face audio course!")
# output["audio"] is a numpy array, output["sampling_rate"] is the rate
```

### Audio Classification
```python
pipe = pipeline("audio-classification", model="facebook/wav2vec2-base")
result = pipe("audio_clip.wav")
print(result)  # List of {label, score} dicts
```

### Load & Process Audio
```python
from datasets import load_dataset, Audio
dataset = load_dataset("superb", "asr", split="train")
dataset = dataset.cast_column("audio", Audio(sampling_rate=16000))
sample = dataset[0]["audio"]["array"]
```

## Pitfalls

- Whisper expects 16kHz mono audio — resample if needed.
- `suno/bark` generates speech slowly on CPU; use GPU or smaller models.
- Audio classification models are domain-specific — music model won't work for speech.
- Long audio exceeds model's max input length — use chunking or `return_timestamps=True`.

## Verification

```python
from transformers import pipeline
pipe = pipeline("automatic-speech-recognition", model="openai/whisper-tiny")
print(pipe("https://huggingface.co/datasets/Narsil/asr_dummy/resolve/main/1.flac")["text"])
```
