# HF Trending Spaces — Live Reference (SakThai Watch)

> **Purpose:** Track notable/trending Hugging Face Spaces discovered during cron ticks.
> **Method:** `GET https://huggingface.co/api/spaces?sort=trendingScore&direction=-1&limit=40` + README inspection.
> **Filter:** Prefer recently created (<30d), unique/creative, high trending score, ZeroGPU, or noteworthy tech.


## Tick: 2026-07-23-b

| # | Space | Creator | What It Does | Why Notable | Links |
|---|-------|---------|-------------|-------------|-------|
| 1 | **gemma-avatar** | victor | Real-time 3D lip-synced avatar powered by Gemma 4 31B — full face-to-face speech conversation | Combines Gemma 4 + Nvidia Parakeet TTS + Qwen3 TTS in a Docker Gradio app; most creative interactive Space on HF right now; 150♥ | [Space](https://huggingface.co/spaces/victor/gemma-avatar) |
| 2 | **OvisOCR2** | ATH-MaaS | Streams structured Markdown from document images and PDFs via multimodal OCR | ZeroGPU (zero-a10g) — built on Qwen3.5-0.8B, outputs clean Markdown from any layout; very practical; 82♥ | [Space](https://huggingface.co/spaces/ATH-MaaS/OvisOCR2) |
| 3 | **Aether-Sovereign-AI** | FINAL-Bench | 100% open Korean foundation model (7B-5Attn MoE) with heterogeneous attention, Apache 2.0 | Fully open weights, data, training logs — rare open-source LLM transparency milestone; 30♥, just 4d old | [Space](https://huggingface.co/spaces/FINAL-Bench/Aether-Sovereign-AI) |

### Honorable Mentions
- **tencent/Hy3** — Tencent hybrid MoE chat with function calling, multi-turn streaming. 53♥. [Space](https://huggingface.co/spaces/tencent/Hy3)
- **ICML-2026-agent-repro/challenge** — Community reproducibility challenge (HF × AlphaXiv) for ICML 2026, agent-driven. 170♥, trending #3. [Space](https://huggingface.co/spaces/ICML-2026-agent-repro/challenge)
- **hugging-apps/gnm** — Interactive 3D face model (Gaussian Neural Mesh Head). [Space](https://huggingface.co/spaces/hugging-apps/gnm)

## Observed Patterns (emerging)

| Pattern | Examples | Notes |
|---------|----------|-------|
| **WebGPU client-side ML** | `webml-community/bonsai-webgpu-kernels` | 1-bit ternary models running fully in-browser via WebGPU — no server GPU needed |
| **Realtime voice AI** | `smolagents/hf-realtime-voice` | Official HF Spaces for WebSocket-based speech-to-speech; smolagents tool integration |
| **Paper-release same-day Spaces** | `microsoft/mage-flow`, `nvidia/Nemotron-Labs-Audex` | Major labs publish interactive demos alongside arxiv/markdown releases |
| **Identity-preserving editing** | `conradlocke/krea2-identity-edit` | Community LoRAs + custom diffusers pipelines for instruction-based image editing |
| **ZeroGPU deployments** | `nvidia/Nemotron-Labs-Audex` | Prebuilt wheels (mamba-ssm Blackwell) for ZeroGPU A10G/RTX 6000 runtimes |

## Tick: 2026-07-23

| # | Space | Creator | What It Does | Why Notable | Links |
|---|-------|---------|-------------|-------------|-------|
| 1 | **bonsai-webgpu-kernels** | webml-community | Runs a 1-bit 27B ternary LLM (Bonsai) entirely in-browser via WebGPU | No server GPU needed — browser-native ML at 27B scale; 295♥, trending #2 | [Space](https://huggingface.co/spaces/webml-community/bonsai-webgpu-kernels) |
| 2 | **hf-realtime-voice** | smolagents (HF) | Voice chat over WebSocket against HF speech-to-speech backend | Opens WebSocket directly (no WebRTC/STUN) — works on cellular/corporate NAT; 454♥ | [Space](https://huggingface.co/spaces/smolagents/hf-realtime-voice) |
| 3 | **mage-flow** | Microsoft | 4B-scale native-resolution image generation & editing via unified Gradio | Brand-new (July 22); Turbo 4-step inference; text-to-image + instruction editing in one app | [Space](https://huggingface.co/spaces/microsoft/mage-flow) |

### Honorable Mentions

- **nvidia/Nemotron-Labs-Audex** — Unified audio-text: ASR, translation, TTS, S2S, reasoning. 30B-A3B MoE. ZeroGPU-ready. [Space](https://huggingface.co/spaces/nvidia/Nemotron-Labs-Audex)
- **conradlocke/krea2-identity-edit** — Identity-preserving instruction editing using Krea 2 + community LoRA. [Space](https://huggingface.co/spaces/conradlocke/krea2-identity-edit)
- **baidu/Unlimited-OCR** — SOTA multilingual OCR on ZeroGPU, trending top-10 for weeks. [Space](https://huggingface.co/spaces/baidu/Unlimited-OCR)
