# HF Papers of the Day — 2026-07-23 (Afternoon)

## Top 3 Picks

### 1. FVAttn: Adaptive Sparse Attention with Runtime Load Balancing for Video Generation
**HF:** https://huggingface.co/papers/2607.16190 · **arXiv:** https://arxiv.org/abs/2607.16190

Video Diffusion Transformers bottleneck on self-attention over long spatio-temporal sequences. FVAttn is a training-free sparse-attention system that uses Top-p routing + a Top-k safety floor + video-aware block organization, then repairs workload imbalance at runtime by migrating heavy heads via P2P communication and filling residual slack with high-value blocks. **Why it matters:** Delivers 4.41× attention speedup over FlashAttention and 2.02–2.11× end-to-end DiT inference speedup on Wan2.2 I2V with competitive quality — a practical recipe for scaling video generation without retraining.

### 2. Trace: A Taxonomy-Guided Environment for Multidomain Visual Reasoning
**HF:** https://huggingface.co/papers/2607.19790 · **arXiv:** https://arxiv.org/abs/2607.19790

RLVR (RL with verifiable rewards) boosted language-model reasoning but extending it to VLMs lacked broad, verifiable, reproducible training data. Trace factorizes task construction into a scene grammar + executable task program — 1,000 tasks over 277 scene grammars and 11 visual domains. RLVR on 64K Trace instances lifts macro-average across 24 external benchmarks by 3.51 pp (Qwen2.5-VL-3B) and 4.06 pp (Qwen2.5-VL-7B). **Why it matters:** First broad, exactly-verifiable visual reasoning training environment — shows that procedural RLVR training transfers beyond generated task distributions.

### 3. DocOps: A Verifiable Benchmark for Autonomous Agents in Complex Document Operations
**HF:** https://huggingface.co/papers/2607.19865 · **arXiv:** https://arxiv.org/abs/2607.19865

Deterministically verifiable evaluation framework for agents manipulating digital documents, built on a hierarchical taxonomy of real-world document operations. Tests reveal that even frontier models (both open and closed) collapse on long-range, highly-coupled tasks. Three key failure modes: long-term state tracking collapse, shallow semantic verification, and destructive editing of structural metadata. **Why it matters:** Exposes a critical blind spot in current agent capabilities — agents can't maintain global document consistency, which limits their utility in real workspace automation.

## Other Notable Papers
- **SeededGrasp: Language-Guided Grasping in Complex Scenes with Multiple Embodiments** (2607.20207) — Decouples VLM semantic reasoning from low-level grasp execution via seed-point conditioning. 72% sim / 78% real, multi-embodiment.
- **G-MAD: A Game-Based Data Generation Framework for Multi-View RGB-T Aerial Object Detection** (2607.19942) — Uses Arma3 game engine to generate synthetic multi-view RGB-Thermal aerial data with auto annotations. Releases AMOD benchmark.
- **Generalizable VLA Finetuning via Representation Anchoring and Language-Action Alignment** (2607.13429) — Prevents BC finetuning from overwriting pretrained VLM representations by anchoring visual features and aligning language-action spaces.
