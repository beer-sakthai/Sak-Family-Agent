# HF Trending Models — Live Reference

> **Purpose:** Track and report currently trending models on Hugging Face Hub.
> **Source:** `GET https://huggingface.co/api/trending`
> **Filter:** `repoType == "model"` (response mixes models, datasets, Spaces)
> **Last updated:** 2026-07-23 (second tick)

## Current Top 5 (2026-07-23)

| # | Model | Creator | Type | Stats | Why Trending |
|---|-------|---------|------|-------|-------------|
| 1 | **thinkingmachines/Inkling** | Thinking Machines Lab | Multimodal MoE (952B) | 24,669⬇ · 1,483♥ | New flagship multimodal — Apache 2.0, image+text+audio |
| 2 | **baidu/Unlimited-OCR** | Baidu | Universal OCR (3.3B) | 2,414,259⬇ · 2,813♥ | SOTA OCR, MIT license, multilingual, arxiv paper |
| 3 | **poolside/Laguna-S-2.1** | Poolside | Code-focused LLM (117B) | 13,285⬇ · 452♥ | Open coding model, openMDW license |
| 4 | **prism-ml/Ternary-Bonsai-27B-gguf** | Prism ML | Ternary 1-bit (27B→~4GB) | 576,083⬇ · 962♥ | Ternary quantization — runs 27B class in <4GB RAM |
| 5 | **DavidAU/Qwen3.6-27B-Fable-Fusion-711-…-GGUF** | DavidAU | Qwen merge (27B) | 334,847⬇ · 366♥ | Latest Qwen-based merge with aggressive uncensored finetune — GGUF format |

Links: [Inkling](https://huggingface.co/thinkingmachines/Inkling) · [Unlimited-OCR](https://huggingface.co/baidu/Unlimited-OCR) · [Laguna-S-2.1](https://huggingface.co/poolside/Laguna-S-2.1) · [Ternary-Bonsai](https://huggingface.co/prism-ml/Ternary-Bonsai-27B-gguf) · [DavidAU Qwen Merge](https://huggingface.co/DavidAU/Qwen3.6-27B-Fable-Fusion-711-Uncensored-Heretic-NM-DAU-NEO-MAX-MTP-GGUF)

## Also Notable

- **zai-org/GLM-5.2** — 753B MoE, 4,350♥, 596K⬇, still strong
- **HauhauCS/Qwen3.6-35B-A3B-Uncensored-HauhauCS-Aggressive** — 2M+⬇, 3,018♥, another Qwen-based merge surging
- **upstage/Solar-Open2-250B** — Dropped to #6 this tick (362⬇, 382♥)
- **Nanbeige/Nanbeige4.2-3B** — Fresh 3B release, 4.5K⬇

## Trends

| Signal | Examples |
|--------|---------|
| Multimodal MoE | Inkling (952B), Unlimited-OCR — both `image-text-to-text` |
| Qwen merge wave | DavidAU, HauhauCS — merged/uncensored Qwen3.6 variants flooding GGUF |
| Ternary quantization | Bonsai family — on-device in browsers |
| Code-specific LLMs | Laguna-S-2.1 |
