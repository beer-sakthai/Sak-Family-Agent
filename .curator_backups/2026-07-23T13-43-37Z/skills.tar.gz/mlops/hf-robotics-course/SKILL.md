---
name: hf-robotics-course
description: "Robot learning with LeRobot — imitation and reinforcement."
version: 0.1.0
author: Hermes
tags: [Robotics, LeRobot, ImitationLearning, RL, HuggingFace]
---

# Robotics with LeRobot

Based on the [HF Robotics Course](https://huggingface.co/learn/robotics-course). Covers classical robotics, imitation learning, and reinforcement learning for robotics using LeRobot and the HF ecosystem.

## When to Use

- User wants to "build a robot" or "train a robotic arm"
- User asks about LeRobot, imitation learning, or sim-to-real
- User needs robotics datasets from the HF Hub
- User wants to implement RL for robotics

## Prerequisites

- `pip install lerobot torch`
- For simulation: a compatible physics engine (MuJoCo, PyBullet)
- Robot dataset from HF Hub

## Quick Reference

| Concept | Tool | Description |
|---------|------|-------------|
| LeRobot | `lerobot` | Robotics dataset & training library |
| Datasets | `lerobot` | Pre-collected robot demonstrations on HF Hub |
| Imitation Learning | `lerobot` | Behavioral cloning from demonstrations |
| RL for Robotics | `lerobot` | Reinforcement learning in simulation |

## Procedure

### Load a robotics dataset
```python
from lerobot.common.datasets.lerobot_dataset import LeRobotDataset
dataset = LeRobotDataset("lerobot/pusht", split="train")
print(len(dataset))  # Number of episodes
```

### Train with imitation learning
```python
from lerobot.common.policies.diffusion import DiffusionPolicy
from lerobot.scripts.train import train

train(
    policy=DiffusionPolicy(),
    dataset=dataset,
    output_dir="./trained_policy",
    num_epochs=50,
)
```

### Evaluate the policy
```python
policy = DiffusionPolicy.from_pretrained("./trained_policy")
# Policy can now be deployed in simulation or on a real robot
```

## Pitfalls

- Real robot hardware requires safety precautions — start in simulation.
- Imitation learning quality depends on demonstration quality.
- LeRobot is actively developed — check docs for API changes.
- Sim-to-real transfer is non-trivial; domain randomization helps.

## Verification

```python
from lerobot.common.datasets.lerobot_dataset import LeRobotDataset
ds = LeRobotDataset("lerobot/pusht", split="train")
print(f"Dataset has {len(ds)} episodes")
```
