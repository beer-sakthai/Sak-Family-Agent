---
name: hf-context-engineering
description: "Context engineering for code agents — skills, MCP, hooks."
version: 0.1.0
author: Hermes
tags: [ContextEngineering, Agents, MCP, Plugins, Subagents, Hooks]
---

# Context Engineering for Code Agents

Based on the [HF Context Course](https://huggingface.co/learn/context-course). Covers building skills, MCP tools, plugins, subagents, and hooks for code agents like Claude Code, Codex, and OpenCode.

## When to Use

- User wants to "structure agent knowledge" or "build agent context"
- User asks about Model Context Protocol (MCP)
- User needs to create skills, plugins, or tool definitions
- User wants to orchestrate multi-agent workflows with subagents
- User needs to observe/monitor agent lifecycle with hooks

## Prerequisites

- A code agent installed (Claude Code, Codex, OpenCode, or Hermes)
- Python 3.10+
- For MCP: an MCP-compatible client (or the `mcp` CLI)

## Course Units Reference

| Unit | Topic | What You Learn |
|------|-------|----------------|
| 1 | Skills | Portable knowledge files agents load automatically |
| 2 | MCP | Model Context Protocol — wire tools and APIs to agents |
| 3 | Plugins | Bundle tools into distributable packages |
| 4 | Subagents | Spawn specialized agents for parallel work |
| 5 | Hooks | Observe, block, and automate the agent lifecycle |
| 6 | Nano Harness | Build a minimal agent loop from scratch |

## Procedure

### Skills
Create markdown files with YAML frontmatter. Agents load them as context:
```yaml
---
name: my-skill
description: "Does XYZ."
---
# Skill Content
Useful reference and procedures here.
```

### MCP (Model Context Protocol)
Run an MCP server to expose tools:
```python
# mcp_server.py
from mcp.server import Server
server = Server("my-tools")
@server.tool()
def my_tool(param: str) -> str:
    return f"Processed {param}"
```

### Subagents
Delegate focused work to child agents with isolated context and tools.

### Hooks
Attach lifecycle scripts at key execution points to enforce guardrails, log errors, or verify outcomes. See the `hooks/` directory for pre/post execution scripts.

### Nano Harness
For understanding how an agent loop works under the hood, see `references/nano-harness.md` — a minimal Observed → Think → Act → Observe loop in ~80 lines of Python.

## Sak Family Application

The 6 concepts map to the Sak Family Agent architecture. All 6 are now built:

| Concept | Sak Family Use | Status | Artifacts |
|---------|----------------|--------|-----------|
| **Skills** | Shared `beer-sakthai/sakthai-skills` repo — all 3 siblings sync via GitHub | Live | Repos: sakthai-skills, saksee-skills, saksit-skills |
| **MCP** | Composio MCP (12+ apps) + n8n (installed) + Linear (needs OAuth) | Live | `config.yaml` `mcp_servers:` section |
| **Subagents** | Formal Research → Build → Verify pipeline in `sak-family-handoff` v2.0.0 | Live | `sak-family-handoff/SKILL.md` |
| **Hooks** | Pre/post guardrails: auto-chown, verify integrity, log error patterns | Live | `hooks/pre-exec-guard.sh`, `hooks/error-capture.sh`, `scripts/post-write-verify.py` |
| **Plugins** | Hermes plugin system explored; 3 types: general, memory, context engine | Scoped | `hermes plugins` interactive UI |
| **Nano Harness** | Minimal agent loop (~80 lines Python) documented | Built | `references/nano-harness.md` |

## Pitfalls

- Skills with overly broad descriptions get loaded often — keep descriptions tight.
- MCP servers must be running for the agent to connect; configure in agent settings.
- Subagents are stateless unless you pass memory explicitly.
- Hooks can slow down the agent if they make network calls on every step.

## Verification

Load a skill via the agent and confirm the content is accessible in context:
```
skill_view(name="my-skill")
```
