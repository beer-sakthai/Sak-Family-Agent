---
name: hf-ml-games
description: "Integrate AI into games — NPCs, tools, Unity, Cubzh."
version: 0.1.0
author: Hermes
tags: [GameDev, AI, NPC, Unity, HuggingFace]
---

# Machine Learning for Games

Based on the [HF ML for Games Course](https://huggingface.co/learn/ml-games-course). Covers building smart NPCs with LLMs, using AI tools in game dev pipelines, integrating models with Unity Sentis, and creating AI-powered game demos.

## When to Use

- User wants to "add AI to a game"
- User asks about NPC behavior with LLMs
- User wants to generate game assets (textures, voice) with AI
- User needs to integrate HF models with Unity or Cubzh

## Prerequisites

- For Unity: Unity Editor + Unity Sentis package
- For Cubzh: Cubzh account (free)
- HF account for model access
- Local or cloud API key for LLM inference

## Quick Reference

| Concept | Tool | Description |
|---------|------|-------------|
| Smart NPCs | LLMs + APIs | Conversational NPCs powered by chat models |
| Unity Sentis | Unity | Run ONNX models directly in Unity runtime |
| AI Art | HF Diffusers | Generate textures, sprites, concept art |
| Voice | HF TTS | Text-to-speech for game dialogue |
| Local Inference | llama.cpp, Ollama | Run models without cloud APIs |

## Procedure

### Build an LLM-powered NPC
1. Pick an LLM (HF Inference API, Ollama, or OpenAI-compatible)
2. Design the NPC's personality prompt
3. Define function calls for in-game actions (move, give item, change state)
4. Call the model API from the game engine

### AI Asset Generation
```python
# Generate textures with Stable Diffusion
from diffusers import StableDiffusionPipeline
pipe = StableDiffusionPipeline.from_pretrained("dreamshaper-8")
image = pipe("game character texture, fantasy style").images[0]
```

### Unity Sentis Integration
Export models to ONNX format, import into Unity, run inference with Sentis:
```
# Convert HF model to ONNX
optimum-cli export onnx --model model-id ./onnx_output
```

## Pitfalls

- LLM inference latency is high for real-time NPC dialogue — cache responses.
- Unity Sentis supports limited ops — test ONNX export compatibility.
- Generated assets may need manual cleanup before use in production.
- Always check model licenses for commercial game use.

## Verification

```python
from transformers import pipeline
pipe = pipeline("text-generation", model="gpt2")
print(pipe("NPC dialogue: Hello adventurer,")[0]["generated_text"])
```
