# BFCL-Style Tool-Calling Benchmark

BFCL (Berkeley Function Calling Leaderboard) evaluates how well models use tools/functions. This reference documents the simplified benchmark used in the SakThai model publishing pipeline.

## Categories

| Category | What it tests | Expected behavior |
|----------|--------------|-------------------|
| **simple** | Single tool with correct arguments | Model calls one function with proper params |
| **simple_python** | Python code execution via tool | Model calls `python_repl` for calculations |
| **multiple** | Parallel tool calls | Model calls 2+ functions in one turn |
| **irrelevance** | Refusing to call tools when irrelevant | Model answers directly, no function call |

## Test prompts used

### simple/get_weather

```python
system: "You have access to get_weather(city: str) -> str. Use it when asked about weather."
prompt: "What's the weather in Paris?"
expected: get_weather(city="Paris") called
```

### simple/search_web

```python
system: "You have access to search_web(query: str) -> list."
prompt: "Search for latest news about AI"
expected: search_web(query="...") called
```

### simple_python/calculate

```python
system: "You have access to python_repl(code: str) -> str."
prompt: "Calculate the factorial of 10"
expected: python_repl(code="...") called
```

### multiple/dual_weather

```python
system: "You have access to get_weather(city: str) -> str. Call multiple functions at once."
prompt: "Weather in Tokyo and London?"
expected: 2+ get_weather() calls in the response
```

### irrelevance/literature

```python
system: "You have access to get_weather(city: str) -> str. Only call for weather."
prompt: "Who wrote Romeo and Juliet?"
expected: Direct answer, NO tool call
```

## How to evaluate

For each test, run the model with the system prompt and user message, then check the response for:

- **simple category**: Does the response contain the expected function name? (string match)
- **multiple category**: Count occurrences of the function pattern `function_name(` — should be ≥2
- **irrelevance**: Check NO function name appears in the response

Results format:

```json
{
  "test": "simple/get_weather",
  "category": "simple",
  "prompt": "What's the weather in Paris?",
  "passed": true,
  "response_preview": "...get_weather(city=\"Paris\")..."
}
```

## Running on CPU (slow but free)

For GGUF models with llama.cpp:

```bash
llama-cli -m model.gguf -p "<full prompt>" --predict 64 --temp 0.1 \
  --no-display-prompt --ctx-size 512 --threads 2 -t 2
```

Expect 1-2 min per test on 2 vCPU for a 1.5B Q4_K_M model. Scale linearly with model size (7B ≈ 4× longer).
