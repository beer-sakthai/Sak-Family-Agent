---
name: model-publishing-pipeline
description: "End-to-end ML model publishing: free-GPU training (Kaggle/Colab), LoRA fine-tuning, GGUF quantization, BFCL benchmark, and HF Hub release with auto-reporting."
version: 1.4.0
author: SakThai Agent
license: MIT
platforms: [linux, macos]
tags: [mlops, training, fine-tuning, kaggle, quantization, gguf, benchmark, publishing, huggingface]
---

# Model Publishing Pipeline

Train → Validate → Quantize → Benchmark → Publish → Report.

Use this skill when the task involves taking a Hugging Face model through the full lifecycle: fine-tuning on cloud GPU, producing quantized variants, running tool-calling benchmarks, and releasing everything to the Hub with structured reports.

## Workflow overview

```
dataset ──→ LoRA training (Kaggle/Colab free GPU)
                  │
                  ├─→ Validation: tool-calling test prompts
                  │
                  ├─→ Push adapter to HF Hub
                  │
                  └─→ Post-training (local or cloud):
                       ├─→ Merge adapter → safetensors
                       ├─→ Quantize to GGUF (Q4_K_M)
                       ├─→ Run BFCL-style benchmark
                       └─→ Push final report + artifacts
```

## Phase 1: Prepare

### Pre-Flight: Asset Audit

Before choosing a GPU source or building a notebook, survey what already exists on the Hub:

```bash
# 1. Check auth
hf auth whoami

# 2. Survey existing models — note lineage (what's trained on what dataset)
hf models list --author <user> --format json

# 3. Find the latest dataset version
hf datasets list --author <user> --format json

# 4. Inspect dataset for pre-built notebooks/scripts
hf datasets info <user>/<dataset>
# Look at siblings array — if notebooks/ or scripts/ dirs exist, download:
hf download --type dataset <user>/<dataset> notebooks/<notebook>.ipynb
hf download --type dataset <user>/<dataset> scripts/<script>.py

# 5. Verify GPU costs before recommending
hf jobs hardware
```

**Audit checklist:**
- □ Authenticated with write token
- □ Previous model lineage known (which dataset each was trained on)
- □ Latest dataset identified with current stats
- □ Pre-built training assets discovered (notebooks, scripts in dataset)
- □ GPU pricing confirmed (free tiers only: Colab T4, Kaggle T4/P100)
- □ Expected success probability and cost estimate prepared

> **Beer's rule:** Every training plan MUST include an expected success probability (%) and cost estimate ($0 or real) before committing. Present options with these upfront — never ask to proceed without them.

### GPU cost warning — HF Jobs are NOT free

Before choosing a GPU source, note that **HF Jobs has no free GPU tier**. Every GPU flavor (`t4-small` at $0.40/hr, `t4-medium` at $0.60/hr, `a10g` at $1–1.50/hr) costs real money. The only free GPU compute for this project comes from external sources (Kaggle, Colab). Always verify `hf jobs hardware` before recommending any compute path and reject paid options by default.

### Choose a free GPU source

| Source | GPU | Limit | Auth Needed |
|--------|-----|-------|-------------|
| **Kaggle** (recommended) | T4 / P100 | 30 hrs/week free | Kaggle API key |
| **Google Colab Free** | T4 | ~1 hr sessions, may disconnect | Google account |
| **Colab Pro** | T4/A100 | ~$10/mo (skip — only free) | N/A for zero-cost |

### Build the training notebook

1. **Base model**: Qwen2.5-7B-Instruct (or 1.5B for smaller/CPU-friendly)
2. **Dataset**: structured tool-calling data in ChatML format
3. **Quantization**: QLoRA 4-bit (BitsAndBytes)
4. **LoRA config**: r=8 for 7B, r=16 for 1.5B; target `q_proj, k_proj, v_proj, o_proj, gate_proj, up_proj, down_proj`
5. **Batch size**: 1 for 7B on T4, gradient_accumulation_steps=16

### Notebook structure (cells to include)

| Cell | Content |
|------|---------|
| 1 | Install deps (`transformers`, `peft`, `trl`, `bitsandbytes`, `huggingface_hub`) |
| 2 | Config block (model ID, dataset ID, output repo names) |
| 3 | Authentication (`HF_TOKEN` from Kaggle Secrets) |
| 4 | Load + format dataset (ChatML → text, count tool-calling vs non-tool) |
| 5 | Load model in 4-bit |
| 6 | LoRA configuration |
| 7 | Training loop (SFTTrainer) |
| 8 | **Validation** — 5 test prompts (simple, parallel, direct answer, HF tool search, cycle-aware energy assess) |
| 9 | **BFCL benchmark** — 3 categories (simple, multiple, irrelevance) |
| 10 | Push adapter to HF |
| 11 | Merge (optional, may OOM on T4) |
| 12 | Generate + push structured JSON report |

## Phase 2: Train on Kaggle

Steps for the user:

1. Go to `kaggle.com` → Create → New Notebook
2. File → Import Notebook from URL
3. Settings → Accelerator → T4 x1 (free)
4. Add-ons → Secrets → `HF_TOKEN` = HF write token
5. Run All (~2-3 hours for 7B, ~30 min for 1.5B)

The notebook auto-generates a JSON report with training metrics, validation scores, and benchmark results, and pushes it to the adapter repo on HF.

### Fallback: Google Drive → Colab (when Kaggle API is unavailable)

If you can't push to Kaggle programmatically (no API key, account suspended, etc.), upload the notebook to Google Drive and open in Colab:

1. Upload the `.ipynb` file to Google Drive (via URL fetch or direct upload)
2. Open the file in Drive → "Open with" → "Google Colab"
3. Runtime → Change runtime type → T4 GPU
4. Set `HF_TOKEN` as a Colab Secret (🔑 key icon in left sidebar)
5. Runtime → Run all

This approach requires manual user action but no setup beyond a Google account. Colab free T4 sessions may disconnect after ~1 hour of inactivity — save checkpoints to Drive.

## Phase 3: Post-process (after Kaggle completes)

Run the post-training script locally or on any machine with Python + PyTorch:

```python
# Step 1: Download adapter from HF
from huggingface_hub import snapshot_download, HfApi
api = HfApi()
snapshot_download(repo_id="Nanthasit/sakthai-7b-lora-kaggle",
                   local_dir="./adapter", repo_type="model")

# Step 2: Merge with base
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel
base = AutoModelForCausalLM.from_pretrained("Qwen/Qwen2.5-7B-Instruct",
    torch_dtype=torch.bfloat16, device_map="auto")
merged = PeftModel.from_pretrained(base, "./adapter").merge_and_unload()
merged.save_pretrained("./merged")
tokenizer.save_pretrained("./merged")
```

### Quantize to GGUF

Requires `llama.cpp` built on the machine:

```bash
# Build llama.cpp (includes convert + quantize tools)
git clone https://github.com/ggml-org/llama.cpp
cd llama.cpp
cmake -B build && cmake --build build --config Release -j$(nproc)

# Convert HF → FP16 GGUF
python3 convert_hf_to_gguf.py ./merged \
    --outfile ./merged/model-f16.gguf --outtype f16

# Quantize to Q4_K_M
build/bin/llama-quantize \
    ./merged/model-f16.gguf \
    ./merged/model-Q4_K_M.gguf Q4_K_M
```

### Run BFCL benchmark

The benchmark evaluates tool-calling across categories:

| Category | Description | Example |
|----------|-------------|---------|
| `simple` | Single tool, correct call | "Weather in Paris?" → `get_weather(city="Paris")` |
| `simple_python` | Python execution via tool | "Factorial of 10" → `python_repl(code="...")` |
| `multiple` | Parallel tool calls | "Weather in Tokyo and London?" → 2x `get_weather()` |
| `irrelevance` | Should NOT call tool | "Who wrote Romeo and Juliet?" → direct answer |

For CPU inference, use `llama-cli` with `--predict 64 --temp 0.1 --threads 2 --no-display-prompt`. Expect 1-2 min per test on CPU (1.5B model). For faster results, use a machine with GPU.

### Push everything to HF

```python
# Upload GGUF
api.upload_file(path_or_fileobj="./merged/model-Q4_K_M.gguf",
    path_in_repo="gguf/model-Q4_K_M.gguf",
    repo_id="org/model-name", repo_type="model",
    commit_message="Add Q4_K_M GGUF quant")

# Upload report
api.upload_file(path_or_fileobj="./results/report.json",
    path_in_repo="results/report.json",
    repo_id="org/model-name", repo_type="model",
    commit_message="Training + benchmark report")
```

## Phase 4: Report

Every pipeline run should produce a structured JSON report with:

```json
{
  "pipeline": "model-name",
  "date": "2026-07-09",
  "training": {
    "model": "base-model",
    "dataset": "Nanthasit/sakthai-combined-v6",
    "samples": 666,
    "final_train_loss": 0.45,
    "best_eval_loss": 0.52
  },
  "validation": [
    {"name": "simple_tool_call", "passed": true}
  ],
  "benchmark": [
    {"test": "simple/get_weather", "category": "simple", "passed": true}
  ],
  "gguf": {
    "quant": "Q4_K_M",
    "size_mb": 935
  }
}
```

## User constraints (zero-cost rule)

This user (Beer) has a **hard zero-cost constraint**:
- NEVER propose or execute anything that requires payment
- All GPU compute must use free tiers (Kaggle, Colab free)
- No Inference Endpoints, no API subscriptions, no paid AutoTrain runs
- Always verify cost before suggesting any action involving compute
- When in doubt, ask "this is free, proceed?" before executing

## Language preference

This user prefers **English only** in all responses. Do not mix languages or use Thai/other languages unless explicitly requested.

## Reference files

This skill ships with detailed reference files:

| File | Covers |
|------|--------|
| `references/gguf-conversion.md` | Full HF→GGUF conversion pipeline, flags, time estimates, common issues |
| `references/bfcl-benchmark.md` | BFCL test categories, prompt templates, evaluation criteria, CPU inference notes |
| `references/synthetic-dataset-generation.md` | Workflow for creating/improving tool-calling fine-tuning datasets: analyzing, filtering, defining schemas, generating synthetic conversations, validating, uploading |
| `references/trust-pass-quality-review.md` | Structured quality review: response naturalness, tool_call_id validation, duplicate detection, schema coverage audits |
| `references/dataset-comparison.md` | A/B comparison between dataset versions: metrics, schemas, density, HF repo status — 'check v5 vs v6 what changed' workflow |
| `references/training-plan-workflow.md` | HF CLI asset-discovery commands, dataset notebook inspection, GPU cost verification, plan presentation template |
| `references/hf-cli-quirks.md` | `hf` CLI gotchas: `--author` vs `--owner`, `--format json`, PATH setup, token precedence — reference for Phase 1 Pre-Flight Audit commands |
| `benchmark/v6-benchmark.ipynb` | Pre-built Kaggle/Colab notebook to run 100-step LoRA + 5-category validation on the v6 dataset (uploaded to `Nanthasit/sakthai-combined-v6`) |


## Trust Pass — Quality Review Before Publishing

Before pushing any dataset or model to production, run a structured Trust pass:

1. **Review stats** — example count, tool-calling ratio, schema coverage, tool_call_id matching
2. **Check response quality** — scan for short/generic responses ("Done.", "Saved.", "Card read."). Replace with natural sentences (15+ chars). Batch-generated templated data often produces these.
3. **Verify structural integrity** — every example must have system+user+assistant; every tool response tool_call_id must match a generated ID from the preceding assistant message
4. **Scan for near-duplicates** — hash the first 200 chars of each example's messages to find suspiciously similar entries
5. **Validate schema coverage** — verify every defined tool schema is actually called at least once. An unused schema wastes training tokens
6. **Document findings** — note what was fixed so Growth captures the lesson

The Trust pass is not optional. It catches issues that automated validation misses, especially response naturalness and token-level correctness.

## Pitfalls

- **Merge OOM on T4**: 7B merge may fail on Kaggle's 16GB T4. Push only the adapter from the notebook, run merge separately on a machine with 32GB+ RAM.
- **CPU benchmark too slow**: 1.5B Q4_K_M at ~10 tok/s on 2 vCPU. Each test takes 1-2 min. For full 7-test BFCL, expect 15-20 min on CPU.
- **Kaggle session timeout**: Sessions disconnect after ~9 hours inactivity. Save checkpoints. The notebook uses `save_steps` to persist progress.
- **HF token as Kaggle Secret**: Use exact name `HF_TOKEN` in Kaggle Secrets UI. The notebook reads `os.environ.get("HF_TOKEN")`.
- **HF dataset card `configs` YAML format**: The `hf upload README.md` command rejects bare key-value pairs in the `configs` section. Wrong: `configs:\n  - train: data/train.jsonl\n  - test: data/test.jsonl`. Correct: `configs:\n  - config_name: train\n    data_files: data/train.jsonl\n  - config_name: test\n    data_files: data/test.jsonl`. Always validate the YAML format before the final upload commit — HF's API enforces this strictly, and the error message is cryptic (\"Invalid metadata\"). Current is `sakthai-combined-v6` (908 train, 113 test, 81 tool schemas, 1,112 tool calls, 22 multi-turn). v5 also available (710 examples with 300 non-tool filler). The format function must handle both tool and non-tool examples. See `references/synthetic-dataset-generation.md` for the full generation workflow.
- **GitHub account suspended**: If the connected GitHub account (beer-sakthai) is suspended, Gist creation for Colab links will fail. Use Google Drive upload as fallback instead.
- **Kaggle API unavailable**: Without a Kaggle API key, notebooks cannot be uploaded or run programmatically. The user must run them manually on kaggle.com or use the Colab fallback.
- **llama-cli interactive mode**: The CLI enters interactive mode after single-turn generation. When calling via subprocess, pass `input="\n"` and strip the interactive `> ` prompts, banner ASCII art, and metadata lines from the output.
- **llama-cli runaway on CPU**: Running llama-cli with an old build (version <4000, commit before 2025) and ChatML models without `--stop "<|im_end|>"` causes an infinite generation loop. The model generates the end-of-turn token, llama-cli doesn't recognize it, and keeps generating at 99%+ CPU indefinitely. Always build/use current llama.cpp and add `--stop "<|im_end|>"` for ChatML models. Use a timeout wrapper as safety net.

## Related

- Bundled skill `huggingface-hub` — for `hf` CLI commands (cannot edit — use for discovery tasks)
- Bundled skill `llama-cpp` — for GGUF discovery and inference (cannot edit — use for finding/downloading existing GGUFs)
- Bundled skill `evaluating-llms-harness` — for MMLU/GSM8K benchmarks (not BFCL — that's covered here)
