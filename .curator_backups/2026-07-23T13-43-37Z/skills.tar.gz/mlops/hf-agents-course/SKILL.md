---
name: hf-agents-course
description: "Build AI agents with smolagents, LlamaIndex, LangGraph."
version: 0.1.0
author: Hermes
tags: [Agents, AI, smolagents, LlamaIndex, LangGraph, HuggingFace]
---

# AI Agents Course Reference

Based on the [HF Agents Course](https://huggingface.co/learn/agents-course). Covers building, testing, and deploying AI agents using smolagents, LlamaIndex, and LangGraph.

## When to Use

- User wants to "build an AI agent"
- User asks about smolagents, LangGraph, or LlamaIndex
- User needs agentic RAG, function-calling, or tool-use patterns
- User wants to deploy agent demos to HF Spaces

## Prerequisites

- `pip install smolagents llama-index langgraph`
- HF account for sharing agents on the Hub
- API key for the LLM provider the agent uses

## Procedure

### smolagents (HF-native)
```python
from smolagents import CodeAgent, HfApiModel

model = HfApiModel("Qwen/Qwen2.5-72B-Instruct")
agent = CodeAgent(tools=[], model=model, add_base_tools=True)
agent.run("Summarize the latest HF blog post")
```

### LlamaIndex
```python
from llama_index.core import VectorStoreIndex, SimpleDirectoryReader
documents = SimpleDirectoryReader("./data").load_data()
index = VectorStoreIndex.from_documents(documents)
query_engine = index.as_query_engine()
response = query_engine.query("What is this about?")
```

### LangGraph
```python
from langgraph.graph import StateGraph
# Define nodes, edges, and state, then compile
graph = StateGraph(state_schema).add_node(...).add_edge(...).compile()
```

## Key Concepts

- **Tools:** Functions the agent can call (web search, calculator, code execution)
- **Agent Loop:** Observe → Think → Act → Observe cycle
- **Memory:** Short-term (conversation context) and long-term (external store)
- **Observability:** Logging traces, monitoring agent decisions

## Pitfalls

- Agents are only as good as their tools — provide well-documented, well-named functions.
- smolagents `CodeAgent` writes and executes Python — be cautious with untrusted input.
- LangGraph is graph-based; think in terms of state transitions, not linear flows.
- Agent loops can be expensive — set `max_iterations` limits.

## Verification

```python
from smolagents import CodeAgent, HfApiModel
agent = CodeAgent(tools=[], model=HfApiModel())
print(agent.run("What is 2+2?"))  # Should return 4
```
