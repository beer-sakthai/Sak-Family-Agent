---
name: hf-deep-rl-course
description: "Train RL agents with Stable Baselines3 and Hugging Face."
version: 0.1.0
author: Hermes
tags: [ReinforcementLearning, RL, DeepRL, StableBaselines, HuggingFace]
---

# Deep Reinforcement Learning with Hugging Face

Based on the [HF Deep RL Course](https://huggingface.co/learn/deep-rl-course). Covers Q-learning, policy gradients, PPO, A2C, multi-agent RL, and training agents in game environments.

## When to Use

- User wants to "train a reinforcement learning agent"
- User asks about PPO, DQN, A2C, or policy gradients
- User wants to use Stable Baselines3 or CleanRL
- User needs RL environments (Atari, Unity ML-Agents, PyBullet)

## Prerequisites

- `pip install stable-baselines3 gymnasium torch tensorboard`
- For Atari: `pip install gymnasium[atari] autorom`
- For Unity ML-Agents: Unity Editor + `pip install mlagents`

## Quick Reference

| Algorithm | Library | Use Case |
|-----------|---------|----------|
| DQN | SB3 | Discrete action spaces (Atari) |
| PPO | SB3 | Continuous/discrete, stable training |
| A2C | SB3 | Synchronous advantage actor-critic |
| SAC | SB3 | Continuous control, sample efficient |
| CleanRL | cleanrl | Readable single-file implementations |

## Procedure

### Train PPO with Stable Baselines3
```python
from stable_baselines3 import PPO
from gymnasium import make

env = make("CartPole-v1")
model = PPO("MlpPolicy", env, verbose=1)
model.learn(total_timesteps=100_000)

model.save("ppo_cartpole")
```

### Test the trained agent
```python
model = PPO.load("ppo_cartpole")
obs, _ = env.reset()
for _ in range(1000):
    action, _ = model.predict(obs, deterministic=True)
    obs, reward, done, truncated, _ = env.step(action)
    if done or truncated:
        obs, _ = env.reset()
env.close()
```

### Log with TensorBoard
```python
model = PPO("MlpPolicy", env, verbose=1, tensorboard_log="./logs/")
```

## Pitfalls

- RL is sample-hungry — expect millions of timesteps for complex environments.
- Hyperparameter tuning is critical — use Optuna or SB3's built-in search.
- Environment wrappers (frame stack, grayscale, resize) are essential for Atari.
- Multi-agent environments need specialized libs (PettingZoo, RLlib).

## Verification

```python
from stable_baselines3 import PPO; env = make("CartPole-v1")
model = PPO("MlpPolicy", env, verbose=0).learn(5000)
obs, _ = env.reset(); print(model.predict(obs, deterministic=True)[0])
```
