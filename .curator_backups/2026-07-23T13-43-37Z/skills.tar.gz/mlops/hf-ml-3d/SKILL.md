---
name: hf-ml-3d
description: "3D machine learning — diffusion, splatting, meshes."
version: 0.1.0
author: Hermes
tags: [3D, GaussianSplatting, NeRF, MultiviewDiffusion, HuggingFace]
---

# Machine Learning for 3D

Based on the [HF ML for 3D Course](https://huggingface.co/learn/ml-for-3d-course). Covers multi-view diffusion, Gaussian splatting, meshes, and building generative 3D demos.

## When to Use

- User wants to "generate 3D models with AI"
- User asks about Gaussian splatting or NeRF
- User wants multi-view diffusion for 3D asset creation
- User needs 3D mesh processing and optimization

## Prerequisites

- `pip install torch diffusers trimesh`
- For Gaussian splatting: CUDA-capable GPU
- For mesh processing: `pip install trimesh pytorch3d`

## Course Units Reference

| Unit | Topic | Description |
|------|-------|-------------|
| 1 | What is 3D? | Foundations: point clouds, meshes, voxels |
| 2 | Multi-view Diffusion | Generate 3D objects from text via multi-view images |
| 3 | Gaussian Splatting | Novel view synthesis with 3D Gaussians |
| 4 | Meshes | Mesh processing, optimization, and generation |
| 5 | Capstone | Build your own generative 3D demo |

## Procedure

### Multi-view Diffusion (text to 3D)
Use models like MVDream or Zero123++ to generate multi-view images from a text prompt, then reconstruct 3D:
```python
# Generate multi-view images with a diffusion model
# Reconstruct 3D via optimization or feed-forward network
# Export as mesh or Gaussian splat
```

### Gaussian Splatting
Optimize 3D Gaussians from multiple views:
```python
# Given calibrated images of a scene
# Initialize 3D Gaussians
# Optimize positions, colors, and covariances via differentiable rendering
# Render novel views in real-time
```

## Pitfalls

- 3D generation is computationally expensive — GPU with ≥16GB VRAM recommended.
- Multi-view diffusion may produce inconsistent views — post-processing needed.
- Gaussian splatting requires multi-view input; doesn't work from a single image.
- Mesh quality from generative methods varies — cleanup in Blender or Meshlab.

## Verification

```python
import trimesh
mesh = trimesh.primitives.Sphere()  # Test trimesh is installed
print(f"Loaded sphere with {len(mesh.vertices)} vertices")
```
