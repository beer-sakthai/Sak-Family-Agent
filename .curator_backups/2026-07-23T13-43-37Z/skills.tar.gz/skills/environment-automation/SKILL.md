---
name: environment-automation
description: "Machine-specific facts and conventions for efficient task execution on this Hermes workspace"
version: 1.1.0
author: SakThai Agent
license: MIT
metadata:
  hermes:
    tags: [environment, automation, paths, conventions, workspace]
    category: productivity
---

# Environment Automation

## Machine
- Host: Linux (6.8.0-134-generic)
- User: `hermes`
- Home: `/opt/data`
- Shell: runs as root but **everything must stay owned by `hermes:hermes`**

## Python
- `python3`: 3.13.5
- `pip`: missing (PEP 668 enforced — system packages blocked)
- `uv`: installed and preferred. Always use `uv` + virtualenvs

## Git
- Repos at `github.com/beer-sakthai/`
- Credentials: HTTPS via `/opt/data/.git-credentials`, SSH via `/opt/data/.ssh/id_github`
- Auto-push blocked — manual confirmation required by Beer
- `git config --global --add safe.directory '*'` to operate in unowned dirs

## Hermes runtime
- Active profile: `sakthai` (this session)
- Profile root: `~/profiles/sakthai/` (NOT `~/.hermes/profiles/sakthai/` — that path does not exist)
- Gateway restart: `setsid hermes [-p profile] gateway run --replace`
- Skills: `~/profiles/sakthai/skills/`
- **Cross-profile guard**: do NOT modify another profile (saksee, saksit, sakking, default) unless explicitly directed
- Profile-switching in commands: use `-p profile_name` flag (e.g., `hermes -p saksee gateway status`)

## Key paths
| What | Path |
|------|------|
| Profile root | `~/profiles/sakthai/` |
| Config | `~/profiles/sakthai/config.yaml` |
| Skills | `~/profiles/sakthai/skills/` |
| Memories | `~/profiles/sakthai/memories/` (MEMORY.md + USER.md, `§`-delimited entries)  |
| Cron | `~/profiles/sakthai/cron/` |
| Cron output | `~/profiles/sakthai/cron/output/` |
| SOUL.md | `~/profiles/sakthai/SOUL.md` |
| State DB | `~/profiles/sakthai/state.db` |
| Sessions | `~/profiles/sakthai/sessions/` |

## Other agents
- SakKing gateway is intentionally stopped (hold file: `/opt/data/state/fleet-watchdog/hold-default`)
- SakSee + SakSit are live, kept alive by `/opt/data/bin/fleet-watchdog.sh`

## Safety rules
- Never expose credentials (`.env`, `auth.json`, `.git-credentials`, `.ssh/`)
- Never commit credential files
- `chown hermes:hermes <file>` after creating/editing any file

## Recurring procedures
- **Daily Briefing** (cron): see `references/daily-briefing.md` — gateway health, memory check, session activity review. Run every morning.

## Reference files

| File | Covers |
|------|--------|
| `references/daily-briefing.md` | Morning briefing: gateway health, memory check, session activity |
| `references/skill-audit.md` | Systematic skill library audit: usage check, frontmatter validation, relevance pruning, clean up |
