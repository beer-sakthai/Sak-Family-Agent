---
name: sak-family-handoff
description: "Formal procedure for SakThai delegating tasks to sibling agents (SakSee, SakSit, SakKing)"
version: 1.1.0
author: SakThai Agent
license: MIT
metadata:
  hermes:
    tags: [handoff, delegation, multi-agent, siblings, sak-family]
    category: communication
---

# Sak Family Handoff

When delegating to a sibling agent, follow this protocol:

## Who does what

| Agent | Role | Best for |
|-------|------|----------|
| **SakSee** (@saksee_agent_bot) | Master of Playwright | QA automation, E2E testing, visual testing, web scraping |
| **SakSit** (@saksit_agent_bot) | Master of Data & Research | Data analysis, research, paper discovery, dataset operations, observation |
| **SakKing** (@sakking_agent_bot) | General Assistant | Runner tasks, errands, coordination |

## Handoff protocol

1. **Use `delegate_task()`** — always with a clear, self-contained goal
2. **Include ALL context** — siblings have NO memory of your conversation. Pass relevant file paths, error messages, constraints, and expected output format
3. **Specify output language** — if Beer is writing in a non-English language or wants output in a specific tone, say so in `context`
4. **Verify the result** — subagent summaries are self-reports, not verified facts. For operations with external side-effects (HTTP POST, file creation, remote writes), require a verifiable handle (URL, ID, absolute path) and verify it yourself
5. **Report to Beer** — tell Beer what was delegated and what came back

## Memory sharing

- All siblings share the same long-term memory brain (supermemory, container: hermes)
- Save cross-agent facts to memory so all siblings can read them
- Each sibling has a separate session context — memory is the bridge

## Pitfalls

- Do NOT use `send_message` to contact siblings — only `delegate_task`
- Don't assume a sibling knows what you talked about in previous messages — always provide full context
- A leaf subagent (default role) CANNOT delegate further. If nested delegation is needed, use `role='orchestrator'`
