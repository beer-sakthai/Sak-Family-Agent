# HF Datasets — Streaming, Parquet & SQL Query Patterns

## Streaming Mode (`load_dataset` with `streaming=True`)

Avoid downloading the full dataset. Yields examples on-the-fly.

```python
from datasets import load_dataset

# Stream — returns IterableDataset, not a full Dataset
ds = load_dataset("bigcode/the-stack-v2-train", streaming=True, split="train")
print(next(iter(ds)))  # first example, zero download
```

**IterableDataset vs Dataset:**
| Feature | Dataset (in-memory) | IterableDataset (streaming) |
|---|---|---|
| Random access | `ds[i]` supported | Sequential only |
| Memory | Entire dataset in RAM | One batch at a time |
| `.map()` | Applies eagerly | Applies lazily on iteration |
| `.shuffle()` | Full shuffle | Buffer shuffle (`buffer_size`) |
| Length | Known (`len(ds)`) | Unknown unless `.num_rows` is set |

### Key IterableDataset Operations

```python
# Take / skip
ds.take(100)    # first 100 examples
ds.skip(1000)   # skip first 1000

# Shard — split into N shards for distributed processing
shard_0 = ds.shard(num_shards=10, index=0)

# Shuffle with buffer
ds = ds.shuffle(buffer_size=10_000, seed=42)

# Map (lazy)
ds = ds.map(lambda x: {"length": len(x["text"])})

# Filter (lazy)
ds = ds.filter(lambda x: x["length"] > 100)

# Batch — group contiguous examples
ds = ds.batch(batch_size=32)
```

### Concatenate & Interleave

```python
# Concatenate multiple iterable datasets
from datasets import concatenate_datasets
combined = concatenate_datasets([ds1, ds2])  # both must be IterableDataset

# Interleave (mix) with probabilities
from datasets import interleave_datasets
mixed = interleave_datasets([ds1, ds2], probabilities=[0.8, 0.2])
```

### Training Loop with Checkpoint/Resume

```python
# state_dict captures shard position + example index for resume
state = iterable_ds.state_dict()
# ... save state dict to disk ...
# On resume:
iterable_ds = load_dataset("...", streaming=True, split="train")
iterable_ds.load_state_dict(state)

# Works with torchdata StatefulDataLoader
from torchdata.stateful_dataloader import StatefulDataLoader
loader = StatefulDataLoader(iterable_ds, batch_size=32, num_workers=4)
state = loader.state_dict()          # checkpoint
loader.load_state_dict(state)        # resume
```

**Caveat:** Shuffle buffer state is LOST on resume — buffer is refilled with new data.

---

## Parquet — The Native HF Dataset Format

### Why Parquet?
- Columnar storage → fast projections (only read columns you need)
- Compressed → ~80% smaller than raw JSON/CSV
- Splittable → distributed processing (Spark, Polars, DuckDB)
- Schema-enforced → typed columns, no parsing ambiguity

### Export Dataset to Parquet

```python
# From regular Dataset
dataset.to_parquet("/path/to/data.parquet")

# From IterableDataset (streaming-friendly)
iterable_ds.to_parquet("/path/to/data.parquet")

# Sharded export for large datasets
num_shards = dataset.num_shards
for i in range(num_shards):
    shard = dataset.shard(index=i, num_shards=num_shards)
    shard.to_parquet(f"/path/to/data-{i:05d}.parquet")
```

### Load Parquet Directly

```python
from datasets import Dataset
ds = Dataset.from_parquet("/path/to/data*.parquet")
```

### Other Export Formats (for IterableDataset)

| Format | Method |
|---|---|
| CSV | `iterable_ds.to_csv("path.csv")` |
| JSON | `iterable_ds.to_json("path.json")` |
| Parquet | `iterable_ds.to_parquet("path.parquet")` |
| SQL | `iterable_ds.to_sql("table_name", "sqlite:///db.sqlite")` |
| Pandas | `iterable_ds.to_pandas()` |
| Polars | `iterable_ds.to_polars()` |
| Dict | `iterable_ds.to_dict()` |

### Push to Hub

```python
# Single-process
dataset.push_to_hub("username/my-dataset")

# Parallel upload (much faster for sharded datasets)
dataset.push_to_hub("username/my-dataset", num_proc=8)
```

HF auto-converts uploaded datasets to Parquet on the backend (eligible datasets).

---

## Hub CLI — Discover & Query Parquet

### List Parquet URLs

```bash
hf datasets parquet cfahlgren1/hub-stats
hf datasets parquet cfahlgren1/hub-stats --subset models
hf datasets parquet cfahlgren1/hub-stats --split train
hf datasets parquet cfahlgren1/hub-stats --format json
```

Returns `subset | split | parquet_url` table.

### Run SQL via DuckDB

```bash
# Count rows
hf datasets sql "SELECT COUNT(*) AS rows FROM read_parquet('https://huggingface.co/api/datasets/cfahlgren1/hub-stats/parquet/models/train/0.parquet')"

# Sample data
hf datasets sql "SELECT * FROM read_parquet('https://huggingface.co/api/datasets/cfahlgren1/hub-stats/parquet/models/train/0.parquet') LIMIT 5" --format json

# Aggregate across columns
hf datasets sql "SELECT author, COUNT(*) as cnt FROM read_parquet('https://huggingface.co/api/datasets/cfahlgren1/hub-stats/parquet/models/train/0.parquet') GROUP BY author ORDER BY cnt DESC LIMIT 10"
```

The parquet URL pattern is:
```
https://huggingface.co/api/datasets/{user}/{repo}/parquet/{subset}/{split}/{shard}.parquet
```

### Install DuckDB (if hf datasets sql fails)

```bash
pip install duckdb
```

---

## Practical Patterns

### 1. Stream → Sample → Export to Parquet (memory-safe)

```python
from datasets import load_dataset

# Stream a massive dataset
ds = load_dataset("HuggingFaceFW/fineweb", streaming=True, split="train")
# Take a sample
sample = ds.take(10_000)
# Export to parquet
sample.to_parquet("fineweb-sample-10k.parquet")
```

### 2. Query Hub Dataset without Downloading

```bash
# Step 1: Find parquet URLs
hf datasets parquet bigcode/the-stack-v2-train --format json

# Step 2: Run SQL against remote parquet
hf datasets sql "
  SELECT COUNT(*) AS repos
  FROM read_parquet('https://huggingface.co/api/datasets/bigcode/the-stack-v2-train/parquet/default/train/00.parquet')
  WHERE language = 'Python'
"
```

### 3. Full Distributed Training Pipeline

```python
# Each worker streams its own shard
rank = int(os.environ["RANK"])
world_size = int(os.environ["WORLD_SIZE"])

ds = load_dataset("bigcode/the-stack-v2-train", streaming=True, split="train")
ds = ds.shard(num_shards=world_size, index=rank)
ds = ds.shuffle(buffer_size=10_000, seed=42)
loader = StatefulDataLoader(ds, batch_size=32)
```

---

## Limitations & Pitfalls

- **No random access** — IterableDataset does NOT support `ds[i]`. Convert to Dataset first with `ds = Dataset.from_iterable_dataset(ds)` (materializes in memory).
- **Shuffle buffer size matters** — Too small = no effective shuffle. Rule of thumb: 10× batch size.
- **`len()` not available** — Call `len(list(ds.take(1000)))` to estimate or set `ds.num_rows = N` if known.
- **Parquet auto-conversion** only applies to datasets uploaded as JSON Lines or raw data, not to binary blobs or individual file formats.
- **`hf datasets sql`** requires DuckDB installed. URLs must be publicly accessible or gated with auth.
