---
name: environment-automation
description: "Machine-specific facts and conventions for efficient task execution on this Hermes workspace"
version: 1.6.0
author: SakThai Agent
license: MIT
metadata:
  hermes:
    tags: [environment, automation, paths, conventions, workspace]
    category: productivity
---

# Environment Automation

## Machine
- Host: Linux (6.8.0-134-generic)
- User: `hermes`
- Home: `/opt/data`
- Shell: runs as root but **everything must stay owned by `hermes:hermes`**

## Python
- `python3`: 3.13.5
- `pip`: missing (PEP 668 enforced — system packages blocked)
- `uv`: installed and preferred. Always use `uv` + virtualenvs

## Git
- Repos at `github.com/beer-sakthai/`
- Credentials: HTTPS via `/opt/data/.git-credentials`, SSH via `/opt/data/.ssh/id_github`
- **Skills auto-sync to GitHub**: cron jobs push to `beer-sakthai/sakthai-skills` automatically. Manual push also available (see `references/sync-skills-to-github.md`).
- `git config --global --add safe.directory '*'` to operate in unowned dirs

## Hermes runtime
- Active profile: `sakthai` (this session)
- Profile root: `~/profiles/sakthai/` (NOT `~/.hermes/profiles/sakthai/` — that path does not exist)
- Gateway restart: `setsid hermes [-p profile] gateway run --replace`
- Skills: `~/profiles/sakthai/skills/`
- **Cross-profile guard**: do NOT modify another profile (saksee, saksit, sakking, default) unless explicitly directed
- Profile-switching in commands: use `-p profile_name` flag (e.g., `hermes -p saksee gateway status`)

## Key paths
| What | Path |
|------|------|
| Profile root | `~/profiles/sakthai/` |
| Config | `~/profiles/sakthai/config.yaml` |
| Skills | `~/profiles/sakthai/skills/` |
| Memories | `~/profiles/sakthai/memories/` (MEMORY.md + USER.md, `§`-delimited entries)  |
| Cron | `~/profiles/sakthai/cron/` |
| Cron output | `~/profiles/sakthai/cron/output/` |
| SOUL.md | `~/profiles/sakthai/SOUL.md` |
| State DB | `~/profiles/sakthai/state.db` |
| Sessions | `~/profiles/sakthai/sessions/` |

## Memory management

Memory lives in two flat files under `~/profiles/sakthai/memories/`:
- **MEMORY.md** — operational facts, skill updates, project notes, lessons learned
- **USER.md** — user identity, preferences, constraints, hard rules

Entries are separated by `§` (section symbol) on its own line. NOT YAML or JSON — plain text blocks delimited by `§`.

**Tool availability differs by session type:**
- Normal (Telegram/cli) sessions: `memory()` tool is available for reading, adding, replacing, removing entries
- Cron sessions (Daily Briefing, Learning Loop): `memory()` tool is **not available**. Use `skill_manage(action='patch')` on a relevant skill's memory-related reference, or use `write_file` to rewrite the entire USER.md/MEMORY.md file. The learning-loop reference (`references/learning-loop.md`) covers the full consolidation workflow.

**Consolidation triggers:**
- Duplicate entries (same semantic content under different `§` blocks) — merge into one
- Stale entries older than 30 days — prune unless still referenced
- Persona-rule violations — completed-work logs and task progress should NOT be in memory (capture those as lessons in skills instead)

## CLI tools

| Tool | Installed at | Notes |
|------|-------------|-------|
| `hf` | `/opt/data/.local/bin/hf` (symlink → `/opt/data/.hf-cli/venv/bin/hf`) | Not in default `PATH`. Use `export PATH="/opt/data/.local/bin:$PATH"` or invoke via full path. |
| `uv` | System-installed (`which uv`) | In default `PATH` — no setup needed. |

## Other agents
- SakKing gateway is intentionally stopped (hold file: `/opt/data/state/fleet-watchdog/hold-default`)
- SakSee + SakSit are live, kept alive by `/opt/data/bin/fleet-watchdog.sh`

## Safety rules
- Never expose credentials (`.env`, `auth.json`, `.git-credentials`, `.ssh/`)
- Never commit credential files
- `chown hermes:hermes <file>` after creating/editing any file

## Recurring procedures
- **Daily Briefing** (cron): see `references/daily-briefing.md` — gateway health, memory check, session activity review. Run every morning.
- **Skills Sync to GitHub** (on-demand): see `references/sync-skills-to-github.md` — backup live skills to `beer-sakthai/sakthai-skills`. Run after skill edits or Beer's request.
- **Learning Loop** (cron, nightly 02:00): see `references/learning-loop.md` — automated session review, memory consolidation, skill patching, and cycle closure. Runs every night.
- **Data Backup to Google Drive + Supermemory** (on-demand): Beer wants ALL important agent data saved to BOTH Supermemory AND Google Drive simultaneously. See `references/google-drive-backup.md` for the Composio MCP workflow — folder discovery, parallel text-file uploads via GOOGLEDRIVE_CREATE_FILE_FROM_TEXT, batch verification.
- **Self-Learning Cron** (as created): see `references/self-learning-cron.md` — autonomous domain learning loop with JSON topic tracker, no-repeat enforcement, and skill improvement per tick. Intended for continuous learning patterns (e.g. HF Learn & Improve Skills, every 1m).

## Reference files

| File | Covers |
|------|--------|
| `references/daily-briefing.md` | Morning briefing: gateway health, memory check, session activity |
| `references/google-drive-backup.md` | Agent data backup to Google Drive + Supermemory using Composio MCP |
| `references/skill-audit.md` | Systematic skill library audit: usage check, frontmatter validation, relevance pruning, clean up |
| `references/sync-skills-to-github.md` | Backup live Hermes skills to GitHub repo |
| `references/learning-loop.md` | Nightly cron: session review, memory consolidation, skill updates, anomaly detection |
| `references/self-learning-cron.md` | Self-learning cron: domain learning + JSON topic tracker + no-repeat + skill improvement per tick |
